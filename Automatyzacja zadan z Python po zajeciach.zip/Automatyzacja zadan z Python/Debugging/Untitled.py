#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def podaj_cyfre():
    try:
        val = int(input("Podaj cyfrę od 0 do 9: "))
        if val > 9 or val < 0:
            raise ValueError()
    except ValueError:
        print("Miałeś podać cyfrę!")
        val = podaj_cyfre()
    return val

